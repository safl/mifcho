import socket
import time

import rfb

addr = (host, port) = ('', 5901)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

s.bind(addr)
s.listen(1)
conn, addr = s.accept()
print 'Connected by', addr
while 1:
    rfb.faked_server(conn)
    time.sleep(4)
conn.close()