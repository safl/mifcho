#!/usr/bin/env python
"""
Contains the version of mifcho.
"""
APP_NAME    = 'mifcho'
APP_VERSION = '0.1'
